package ru.ostrov77.twist.Objects;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.io.File;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.entity.Firework;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import com.xxmicloxx.NoteBlockAPI.NBSDecoder;
import com.xxmicloxx.NoteBlockAPI.RadioSongPlayer;
import com.xxmicloxx.NoteBlockAPI.Song;
import io.puharesource.mc.titlemanager.api.ActionbarTitleObject;
import io.puharesource.mc.titlemanager.api.TitleObject;
import java.util.HashMap;
import org.bukkit.entity.Entity;
import org.bukkit.entity.PigZombie;
import org.bukkit.inventory.meta.ItemMeta;

import ru.komiss77.Ostrov;
import ru.ostrov77.twist.Main;
import ru.ostrov77.twist.Manager.Arenas;
import ru.ostrov77.twist.Manager.Signs;



public class Arena {

    private String name;
    private Location arenaLobby;
    private Location zero;
    private String mode;    
    private Material mat;    
    private byte size_x;
    private byte size_z;
    private byte difficulty;
    private byte maxRound;
    private byte minPlayers;
    private byte playersForForcestart;
    
    
    private BukkitTask CoolDown;
    private byte cdCounter;
    private BukkitTask PreStart;
    private byte prestart;
    private BukkitTask GameTimer;
    private short playtime;
    private BukkitTask EndGame;
    private byte ending;
    private BukkitTask DysplayColor;
    private BukkitTask RemoveFloor;
    
    private boolean canreset;
    
    private byte round;
    private byte curr_color;

    private boolean displayColor;
    private boolean removeFloor;


    private List<Player> players = new ArrayList();
    private ArrayList<Byte> colormap = new ArrayList<>();    
    private HashMap<String,List<Entity>> pigzombie = new HashMap<>();    
    
    private ItemStack no_mat; 
    private RadioSongPlayer songPlayer;    
    private static Random random;
    private GameState state;
    
    
    
    
    public Arena( String name, Location zero, Location arenaLobby,  String material, byte size_x, byte size_z, byte difficulty, byte maxRound, byte minPlayers, byte playersForForcestart ) {
        
        if (Arenas.getManager().ArenaExist(name)) return; //не создаём дубль!!
        
        this.name = name;
        try {
            this.arenaLobby = arenaLobby;
            this.zero = zero;
        } catch (NullPointerException e) {}
        
        switch (material) {
            case "clay" : mat = Material.STAINED_CLAY;  this.mode="clay"; break;
            case "glass": mat = Material.STAINED_GLASS; this.mode="glass"; break;
            default     : mat = Material.WOOL;          this.mode="wool"; break;
        }
        
        if ( size_x>=2 && size_x<=64 )  this.size_x = size_x; else  this.size_x = 16; 
        if ( size_z>=2 && size_z<=64 ) this.size_z = size_z; else this.size_z = 16;
        if ( difficulty>=1 && difficulty <=3 ) this.difficulty = difficulty; else this.difficulty = 1;
        if ( maxRound>=1 && maxRound<=64 ) this.maxRound = maxRound; else this.maxRound = 10; 
        if ( minPlayers>=2 && minPlayers<=64 ) this.minPlayers = minPlayers; else this.minPlayers = 2;
        if ( playersForForcestart>=2 && playersForForcestart<minPlayers ) this.playersForForcestart = playersForForcestart; else this.playersForForcestart = 12;

System.out.println("Создана арена "+name+"   размер "+this.size_x+"*"+this.size_z+
        " diff "+this.difficulty+" раунды "+this.maxRound+" игроки/быстро "+this.minPlayers+"/"+this.playersForForcestart);
        
        this.cdCounter = 40; //ожид в лобби арены
        this.prestart = 7; //ожид на арене
        this.ending = 7; //салюты,награждения
        this.playtime = 0;
        
        this.canreset = true;
        
        this.round = 1; 
        this.curr_color = 0;
        this.displayColor = true;
        this.removeFloor = false;
        random = new Random();
        
        no_mat = new ItemStack ( Material.STONE_BUTTON, 1);

        GenerateNewFloor();

        this.state=GameState.WAITING;
        
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
 
 
    
public void startCountdown() {                            //ожидание в лобби
        if (getState() != GameState.WAITING) return;
        setState(GameState.STARTING);
        
        SendTitle("§aЗмейка стартует через", "§b"+cdCounter+" сек.!");
        if (Main.noteblock) StartMusic ();

        this.CoolDown = (new BukkitRunnable() {
            @Override
            public void run() {
                
                if (cdCounter == 0) {
                        Arena.this.cdCounter = 40;
                        this.cancel();
                        PrepareToStart();
                
                } else if ( arenaLobby.getWorld().getPlayers().size() < minPlayers ) {
                    SendAB("§d§lНедостаточно участников, счётчик остановлен.");
                    setState(GameState.WAITING);
                    Arena.this.cdCounter = 40;
                    this.cancel();
                    
                } else if ( arenaLobby.getWorld().getPlayers().size() == playersForForcestart && cdCounter > 10 ) {
                    SendAB("§2§lВремя до старта игры уменьшено!");
                    cdCounter = 10;
                    
                } else if (cdCounter > 0) {
                        --cdCounter;
                        //SendAB("§aДо старта: "+cdCounter);
                        if (cdCounter <= 5 && cdCounter > 0) {
                            SendTitle("§b"+cdCounter+" !", "");
                            SendSound(Sound.BLOCK_COMPARATOR_CLICK);
                        }
                } 

            }
        }).runTaskTimer(Main.GetInstance(), 0L, 20L);
    }


    
public void ForceStart() {
     if (getState() != GameState.STARTING) return;
        if (CoolDown != null && cdCounter>3)  cdCounter=3;
        PrepareToStart();
    }





    
public void PrepareToStart() {   
    if (getState() != GameState.STARTING) return;
    setState(GameState.STARTED);
    if (this.CoolDown != null)  this.CoolDown.cancel();
    
    
        for (int i=0; i<arenaLobby.getWorld().getPlayers().size(); i++) {  //всех игроков в мире добавля в список и на арену  
            Player p = arenaLobby.getWorld().getPlayers().get(i);
            players.add(p);
            p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 5, 1), true);
            p.getInventory().clear();
            p.teleport( this.zero.clone().add(  (4 + random.nextInt(this.size_x-2)*4) , 1, (4 + random.nextInt(this.size_z-2)*4) ) );
        }
        
    
    
            this.PreStart = (new BukkitRunnable() {         //тут уже таймер с игроками
            @Override
            public void run() {
                
                    if ( players.isEmpty() && canreset ) resetGame();

                        if ( players.size() < minPlayers ) {
                            SendAB("§d§lСлишкома мало игроков, отмена.");
                            this.cancel();
                            if (canreset) resetGame();
                            
                        } else if (prestart==0) {
                            prestart = 7;
                            this.cancel();
                            GameProgress();
                            
                        } else {
                            SendAB("§aТвист заражается... Осталось §b"+prestart+" §aсекунд!");
                            SendSound(Sound.ENTITY_CAT_PURR);
                            --prestart;
                        }
                    
            }
            }).runTaskTimer(Main.GetInstance(), 0L, 20L);
    }
    
 


















public void GameProgress() {
    if (getState() != GameState.STARTED) return;
    setState(GameState.INGAME);
    if (this.PreStart != null)  this.PreStart.cancel();
    
    

    SendAB("§6ТВИСТ! §aТВИСТ! §bТВИСТ!");
        SendSound(Sound.ENTITY_CAT_AMBIENT);
        
        this.displayColor = true;
        this.removeFloor = false;
        

        this.GameTimer = (new BukkitRunnable() {
            @Override
            public void run() {
                
                
                if (displayColor) {
                    
                    if (Arena.this.RemoveFloor != null)  Arena.this.RemoveFloor.cancel();
                    DysplayColor();                                             //показываем инфо
                    
                } else if (removeFloor) {

                    if (Arena.this.DysplayColor != null)  Arena.this.DysplayColor.cancel();
                    
                    MustStayOne();                                              //удаляем все вроме текущего цвета
                                                                //эта же функция возвращает новый пол через 3 сек
                    Arena.this.round++;
                    
                }
                
                
                
                
                
                if ( players.isEmpty() || playtime > maxRound*difficulty*20 && canreset) {
                    SendTitle("Время вышло!", "Игра окончена!");
                    resetGame();
                } else if (Arena.this.players.size()==1) {
                        this.cancel();
                        endGame();
                } else if ( Arena.this.round >= Arena.this.maxRound ) {
                        this.cancel();
                        endGame();
                }

                Arena.this.playtime++;
                
            }
        }).runTaskTimer(Main.GetInstance(), 0L, 20L);

}







































public void endGame() {   
    if (getState() != GameState.INGAME) return;
    state=GameState.ENDING;
    if (this.GameTimer != null)  this.GameTimer.cancel();
    if (this.DysplayColor != null)  this.DysplayColor.cancel();
    if (this.RemoveFloor != null)  this.RemoveFloor.cancel();
    
    Signs.SignsUpdate ( getName(), 1, getStateAsString(), playtime );
    
        
        for (Player win : players) {
            win.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 150, 0));
            (new TitleObject (("§aВы победили!"), TitleObject.TitleType.TITLE)).setFadeIn(5).setStay(30).setFadeOut(10).send(win);
            (new TitleObject (("§fВаша награда - 300р. на счёт !"), TitleObject.TitleType.SUBTITLE)).setFadeIn(5).setStay(30).setFadeOut(10).send(win);
            win.playSound(win.getLocation(), Sound.BLOCK_ANVIL_FALL , 1.0F, 1.0F);
                if (Main.ostrov) Ostrov.SetBalance ( win, Ostrov.GetBalance(win) + 300 );
                else Bukkit.dispatchCommand( Bukkit.getServer().getConsoleSender(), "telleaw "+win.getName()+" награда!" ); 
            firework(win);
        }

        this.EndGame = (new BukkitRunnable() {
            @Override
            public void run() {
                        
                        SendSound(Sound.BLOCK_COMPARATOR_CLICK);
                        
                        if (ending <=0) {
                             this.cancel();
                             resetGame();
                        }

                        --ending;
            }
        }).runTaskTimer(Main.GetInstance(), 0L, 20L);
        
        
 

    
}





public void resetGame() {  

    this.canreset=false;

    this.arenaLobby.getWorld().getPlayers().stream().forEach((p) -> { p.teleport(Bukkit.getServer().getWorlds().get(0).getSpawnLocation()); });
    
    stopShedulers();    
    
    //this.arenaLobby.getWorld().getPlayers().stream().forEach((p) -> { p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 10, 1), true); });
    this.arenaLobby.getWorld().getEntities().stream().forEach((e) -> {  try {e.remove();} catch (NullPointerException ex) {}     });
    
    this.players.clear();

    this.round=1;

    this.cdCounter=40;
    this.prestart = 7;
    this.ending=10;
    this.playtime = 0;
    
    this.round = 1; 
    this.curr_color = 0;
    this.displayColor = true;
    this.removeFloor = false;

    GenerateNewFloor();
    
    setState(GameState.WAITING);
    this.canreset=true;

    if (Main.noteblock) StopMusic();
}


public void stopShedulers() {  
    if (this.CoolDown != null)  this.CoolDown.cancel();
    if (this.EndGame != null)  this.EndGame.cancel();
    if (this.PreStart != null)  this.PreStart.cancel();
    if (this.GameTimer != null)  this.GameTimer.cancel();
    if (this.DysplayColor != null)  this.DysplayColor.cancel();
    if (this.RemoveFloor != null)  this.RemoveFloor.cancel();
}
    
 












 
    
    
    

    
 
    
    




   
    
    
    
public void addPlayers(Player p) {
    if ( IsJonable() ) {
        p.teleport(arenaLobby);
        if ( arenaLobby.getWorld().getPlayers().size() <= minPlayers ) SendAB ("§6Для старта нужно еще §b" + ( minPlayers-arenaLobby.getWorld().getPlayers().size())+" §6чел.!" ); 
        Main.GiveExitItem(p);
        p.updateInventory();
        Signs.SignsUpdate(name, players.size(), getStateAsString(), playtime );
        if ( arenaLobby.getWorld().getPlayers().size()>=minPlayers ) startCountdown();
    }
}

    
    
public void PlayerExit (Player p) {
        
       
    if ( IsJonable() ) {                //если ожидание или первый таёмер, т.е. не внесён в players
        if ( this.players.contains(p) ) this.players.remove(p);         //перестраховка
            if (arenaLobby.getWorld().getPlayers().size() < minPlayers && this.CoolDown != null) {      //если был запущен таймер
                this.CoolDown.cancel();
                Arena.this.cdCounter = 40;
                SendAB("§d§lНедостаточно участников, счётчик остановлен.");
                setState(GameState.WAITING);
            }
            new ActionbarTitleObject ("§fВы вышли с арены!").send(p);
            p.teleport(Bukkit.getServer().getWorlds().get(0).getSpawnLocation());
            Signs.SignsUpdate( getName(), players.size(), getStateAsString(), playtime );
        
    } else {                                            //выход во время игры-возможно только через отключение
            if ( this.players.contains(p) ) {
            this.players.remove(p);
            if ( players.size() ==1 ) endGame();    
            Signs.SignsUpdate( getName(), players.size(), getStateAsString(), playtime );
            }
    }


    }



public void Loose (Player p) {
    
    if ( !this.players.contains(p) ) return;
                
    this.players.remove(p);
    if ( players.size() ==1 ) endGame();    
                
    p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 60, 1), true);
    p.getWorld().playSound(p.getLocation(), Sound.ENTITY_ENDERDRAGON_GROWL , 0.8f, 2.0f);
    (new TitleObject (("§4Вы проиграли!"), TitleObject.TitleType.TITLE)).setFadeIn(5).setStay(20).setFadeOut(60).send(p);
    (new TitleObject (("§4Примите смерть достойно!"), TitleObject.TitleType.SUBTITLE)).setFadeIn(5).setStay(20).setFadeOut(60).send(p);
    Signs.SignsUpdate( getName(), players.size(), getStateAsString(), playtime );
    
    //p.teleport(arenaLobby);
    if (canreset) {
        p.setWalkSpeed(0.09F);
        p.getInventory().clear();
        
        List <Entity>pigz = new ArrayList();

        for (byte z= 0; z<=6; z++) {
            PigZombie pz = p.getWorld().spawn( p.getLocation().clone().add( z-3,0,z-3), PigZombie.class);
            pz.setAngry(true);
            pz.setCustomName("Инквизитор");
            pz.getEquipment().setItemInMainHand(new ItemStack(Material.CARROT, 1));
            pigz.add(pz);
        }
        this.pigzombie.put(p.getName(), pigz);
    }
                
}
    
    
public void RemovePZ (String nik) {
    
    if ( !this.pigzombie.containsKey(nik)) return;
    
    List <Entity>pigz = this.pigzombie.get(nik);
    
    pigz.stream().forEach((pz) -> {
        try { pz.remove();} catch (NullPointerException e) {}
    });
    
}




















    
    
    
    public boolean IsInGame(Player p) {
        return this.players.contains(p);
    }
    
    public boolean IsJonable() {
        return ( state == GameState.WAITING || state == GameState.STARTING );
    }
    

    
    
    
    public List<Player> getPlayers() {
        return this.players;
    }

    public String getName() {
        return this.name;
    }

    public GameState getState() {
        return this.state;
    }
    
   public void setState(GameState gamestate) {
        this.state = gamestate;
        Signs.SignsUpdate( getName(), players.size(), getStateAsString(), playtime );
    }
   
   public String getStateAsString() {
        switch (this.state) {
            case WAITING:
                return "§b§lОЖИДАНИЕ";
            case STARTING:
                return "§6§lСКОРО СТАРТ!";
            case STARTED:
                return "§5§lСТАРТУЕТ";
            case INGAME:
                return "§4§lИГРА";
            case ENDING:
                return "§9§lЗАВЕРШАЕТСЯ";
            default:
                return "";
        }
    }

   
   public String getScoreTimer() {
        switch (getState()) {
            case INGAME:
                return "§7Время: §f§l"+Main.getTime(this.playtime);
            case WAITING:
                return "§aОжидаем игроков.. (§b"+(this.minPlayers-this.players.size())+"§a)";
            case STARTING:
                return "§7До старта: §b§l"+this.cdCounter ;
            case STARTED:
                return "§f§lЗаправка сеном.." ;
            default:
                return getStateAsString();
        }
   }
   
    public String GetScoreStatus (Player p) {
        if (!players.contains(p)) return "§f§o- Зритель -";
        //else if (state == GameState.WAITING || state == GameState.STARTING ) return Main.EnumColor(GetSheepColor(p.getName()))+p.getName();
        //else if (this.playerTracker.containsKey(p)) return "§2§o✔ "+Main.EnumColor(GetSheepColor(p.getName()))+p.getName();
        else return "§4§o✖ "+p.getName();
    }
    
    
    
    
    
    public Location getZero() {
        return this.zero;
    }

    public Location getLobby() {
        return this.arenaLobby;
    }

    public void setLobby(Location location) {
        this.arenaLobby = location;
    }
    
    public String getMode() {
        return this.mode;
    }
   
    public byte getSize_x() {
	return this.size_x;
    }

    public byte getSize_z() {
	return this.size_z;
    }

    public byte getDifficulty() {
	return this.difficulty;
    }

    public void setDifficulty( byte d ) {
	this.difficulty = d;
    }

    public byte getMaxRound() {
	return this.maxRound;
    }

    public void setMaxRound( byte d ) {
	this.maxRound = d;
    }
    
    public byte getMinPlayers() {
        return this.minPlayers;
    }
    
    public void setMinPlayers( byte i ) {
         this.minPlayers=i;
    }

    public byte getForce() {
	return this.playersForForcestart;
    }

    public void setForce( byte d ) {
	this.playersForForcestart = d;
    }






    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public void SendAB(String text) {
        arenaLobby.getWorld().getPlayers().stream().forEach((p) -> {
            new ActionbarTitleObject (text).send(p);
        });
    }
    
    public void SendSound(Sound s) {
        arenaLobby.getWorld().getPlayers().stream().forEach((p) -> {
            p.playSound(p.getLocation(), s , 5.0F, 5.0F);
        });
    }

    public void SendTitle(String t, String st) {
        arenaLobby.getWorld().getPlayers().stream().forEach((p) -> {
(new TitleObject ((t), TitleObject.TitleType.TITLE)).setFadeIn(20).setStay(20).setFadeOut(5).send(p);
(new TitleObject ((st), TitleObject.TitleType.SUBTITLE)).setFadeIn(20).setStay(20).setFadeOut(5).send(p);
        });
    }
    


    
    


 
    
///салютики
    private static void firework (Player p) {
        
        for (int i = 0; i < 6; ++i) {                           //салютики
            new BukkitRunnable() {
                @Override
                public void run() {
            Random random = new Random();
            Firework firework = (Firework) p.getWorld().spawn(p.getLocation().clone().add(0, 5, 0), Firework.class);
            FireworkMeta fireworkmeta = firework.getFireworkMeta();
            FireworkEffect fireworkeffect = FireworkEffect.builder().flicker(random.nextBoolean()).withColor(Color.fromBGR(random.nextInt(256), random.nextInt(256), random.nextInt(256))).withFade(Color.fromBGR(random.nextInt(256), random.nextInt(256), random.nextInt(256))).with(FireworkEffect.Type.STAR).trail(true).build();

            fireworkmeta.addEffect(fireworkeffect);
            firework.setFireworkMeta(fireworkmeta);   
                }}.runTaskLater(Main.GetInstance(), (long)(i * 5));}
    }
    
    
    
    
 


    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    



   
    
    
    
    
    
    
    
    
    
    
    
 private void StartMusic () {
    
    try {
        if (Bukkit.getPluginManager().isPluginEnabled("NoteBlockAPI")) {
                
            File[] files = new File(Main.GetInstance().getDataFolder().getPath() + "/songs/").listFiles();
            List<File> songs = new ArrayList<>();
            for (File f : files)
                if (f.getName().contains(".nbs")) songs.add(f);
            File song = songs.get(new Random().nextInt(songs.size()));
            Song s = NBSDecoder.parse(song);
            
           // songPlayer = new PositionSongPlayer(s);
            songPlayer = new RadioSongPlayer(s);
            songPlayer.setAutoDestroy(true);

            //songPlayer.setTargetLocation(arenaLobby);
            songPlayer.setPlaying(true);

            arenaLobby.getWorld().getPlayers().stream().forEach((p) -> { songPlayer.addPlayer(p); });

            songPlayer.setVolume((byte) 60);
            songPlayer.setFadeStart((byte) 25);
        }
    } catch (NullPointerException e){}
    
}


private void StopMusic () {
    try {
        if (Bukkit.getPluginManager().isPluginEnabled("NoteBlockAPI")) {
            songPlayer.setPlaying(false);
            this.songPlayer.destroy(); 
        }
    } catch (NullPointerException e){}
}

   
 












public void DysplayColor () {
    
    this.curr_color = GenRandColor();
        
    this.displayColor=false;
    this.removeFloor =false;
    
    ItemStack item = new ItemStack(mat, 1, curr_color );
    ItemMeta m = item.getItemMeta();
    m.setDisplayName(  Main.DyeToString(curr_color)[0] + "§l" + Main.DyeToString(curr_color)[1] );
    item.setItemMeta(m);

    players.stream().forEach((p) -> {
        for (byte i=0; i<9; i++) {
            p.getInventory().setItem(i, item);
            p.updateInventory();
        }
    });
    
    
    
    
        this.DysplayColor = (new BukkitRunnable() {
            
            byte i=8;
            @Override
            public void run() {
                
                for ( Player p : players) {
            
                /*    BossBarAPI.removeAllBars(p);
                    BossBarAPI.addBar( p,  new TextComponent( Main.DyeToString(curr_col)[1]+ Main.DyeToString(curr_col)[2] + "!"),
                        BossBarAPI.Color.YELLOW,  BossBarAPI.Style.NOTCHED_20,  1.0f,  20,  2 );*/
                    
                    p.getInventory().setItem( i, no_mat );
                    p.updateInventory();
                    
                    switch (i) {
                        case 8: p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP , 1, 0);
                        case 5: p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP , 1, 0);
                        case 2: p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP , 1, 0);
                    }
            
                }
                    i--;
                    if ( i < 0 ) {
                        displayColor = false;
                        removeFloor = true;
                        this.cancel();
                    }
                
            }
        //}).runTaskTimer( Main.GetInstance(), (80L - (difficulty * 20) - n) / 12, (80L - (difficulty * 20) - n) / 12 );
        //}).runTaskTimer( Main.GetInstance(), ( 80L - ( difficulty * 20 ) - this.round ) , (80L - ( difficulty * 20 ) - this.round ) );
        }).runTaskTimer( Main.GetInstance(), 20 , 40 );
        

    }









private void MustStayOne() {                     //удал все цвета, кроме текущего
    
long t = System.currentTimeMillis();

    this.displayColor=false;
    this.removeFloor =false;
    int curr_plot=0;
    
        for (byte x=0; x<=this.size_x; x++) {
            for (byte z=0; z<=this.size_z; z++) {
                
               if ( this.colormap.get(curr_plot) != this.curr_color ) FillPlotAir( x, z );
               curr_plot++;
                
            }
        }            
                
System.out.println("Оставить один: "+(System.currentTimeMillis()-t));
                
        this.RemoveFloor = (new BukkitRunnable() {
            @Override
            public void run() {
                Arena.this.BackFloor();
                Arena.this.displayColor=true;
                Arena.this.removeFloor =false;
            }
        }).runTaskLater(Main.GetInstance(), 60 );
                
    }
        




private void BackFloor() {                     //вернуть пол

long t = System.currentTimeMillis();    
System.out.println("-------вернуть!------");    
    int curr_plot=0;
    
    ArrayList <Byte> temp = new ArrayList<>();
    
        for (byte x=0; x<=this.size_x; x++) {
            for (byte z=0; z<=this.size_z; z++) {
//long t2 = System.currentTimeMillis();                 
                byte col = GenRandColor();
                
               if ( this.colormap.get(curr_plot) == this.curr_color ) {         //если плот был оставлен
                   //temp.put ( curr_plot, curr_color );              //прописываем на след.раунд новый цвет
                   temp.add ( curr_plot, col );              //прописываем на след.раунд новый цвет, но не заполняем
               } else {
                  FillPlotMat ( x , z, col );
                  temp.add ( curr_plot, col );
               }
               curr_plot++;
//System.out.println("Вернуть плот: "+x+"*"+z+" цвет:"+col+" время:"+(System.currentTimeMillis()-t2));                 
            }
        }            
    
    this.colormap = temp;
System.out.println("------------------->Вернуть пол: "+(System.currentTimeMillis()-t));    
    
    }









private void GenerateNewFloor() {

long t = System.currentTimeMillis();
    
    this.colormap.clear();
    int curr_plot=0;
    
        for (byte x=0; x<=this.size_x; x++) {
            for (byte z=0; z<=this.size_z; z++) {
                
               byte col = GenRandColor();
               this.colormap.add(curr_plot, col );
               FillPlotMat ( x , z, col ); 
               FillDown ( x , z ); 
               curr_plot++;
                
            }
        }            

System.out.println("Генерация нового пола: "+(System.currentTimeMillis()-t));      
        
    }



    
    
public void ResetFloor() {

        for (byte x=0; x<=this.size_x; x++) {
            for (byte z=0; z<=this.size_z; z++) {
                
               FillPlotAir(x , z );
                FillDownAir(x, z);
                
            }
        }

        this.colormap.clear();
    
}    



























private void FillPlotMat ( byte plot_x, byte plot_z, byte c ) {
    
    int x = plot_x * 4;
    int z = plot_z * 4;
    
    for (byte x_ = 0; x_ < 4; x_++) {
	for (byte z_ = 0; z_ < 4; z_++) {
            
            //Block b = this.zero.getWorld().getBlockAt( this.zero.clone().add ( x+x_, 0, z+z_) );
            this.zero.getWorld().getBlockAt( this.zero.clone().add ( x+x_, 0, z+z_) ).setType(mat);
            this.zero.getWorld().getBlockAt( this.zero.clone().add ( x+x_, 0, z+z_) ).setData(c);
           // b.setType( mat );
            //b.setData( (byte) color );
            
	}
    }
    
}



private void FillPlotAir ( byte plot_x, byte plot_z ) {
    
    int x = plot_x * 4;
    int z = plot_z * 4;
    
    for (byte x_ = 0; x_ < 4; x_++) {
	for (byte z_ = 0; z_ < 4; z_++) {
            
            this.zero.getWorld().getBlockAt( this.zero.clone().add ( x+x_, 0, z+z_) ).setType( Material.AIR );
            
	}
    }
    
}


private void FillDown ( byte plot_x, byte plot_z ) {
    
    int x = plot_x * 4;
    int z = plot_z * 4;
    
    for (byte x_ = 0; x_ < 4; x_++) {
	for (byte z_ = 0; z_ < 4; z_++) {
            
            this.zero.getWorld().getBlockAt( this.zero.clone().add ( x+x_, -7, z+z_) ).setType( Material.GLOWSTONE );
            
	}
    }
    
}

private void FillDownAir ( byte plot_x, byte plot_z ) {
    
    int x = plot_x * 4;
    int z = plot_z * 4;
    
    for (byte x_ = 0; x_ < 4; x_++) {
	for (byte z_ = 0; z_ < 4; z_++) {
            
            this.zero.getWorld().getBlockAt( this.zero.clone().add ( x+x_, -7, z+z_) ).setType( Material.AIR );
            
	}
    }
    
}



private Byte  GenRandColor () {
//long t = System.currentTimeMillis();
    byte p = (byte) random.nextInt( Main.allowedColors.size()-1 );
//System.out.println("Генерация случ.цвета: "+(System.currentTimeMillis()-t));   
    return Main.allowedColors.get( p ); 
} 















        
        
        
        
        




























    
}
