package ru.ostrov77.twist.Objects;

public enum GameState {

    WAITING, STARTING, INGAME, STARTED, ENDING;
}
