package ru.ostrov77.twist;

import java.io.File;
import java.io.IOException;
import org.bukkit.configuration.file.FileConfiguration;







public class MainConfig {


    public static File folder;
    public static FileConfiguration config; 
    
	public static int rounds_per_game = 10;
	public static int default_max_players = 4;
	public static int default_min_players = 3;

	public static int reward = 30;
	public static int itemid = 264;
	public static int itemamount = 1;
	public static boolean command_reward = false;
	public static String cmd = "";
	public static boolean start_announcement = false;
	public static boolean winner_announcement = false;
	public static boolean bling_sounds = false;

	public static int start_countdown = 5;
        
	public static String saved_arena = "";
	public static String saved_lobby = "";
	public static String saved_setup = "";
	public static String saved_mainlobby = "";
	public static String not_in_arena = "";
	public static String reloaded = "";
	public static String arena_ingame = "";
	public static String arena_invalid = "";
	public static String arena_invalid_sign = "";
	public static String you_fell = "";
	public static String arena_invalid_component = "";
	public static String you_won = "";
	public static String starting_in = "";
	public static String starting_in2 = "";
	public static String arena_full = "";
	public static String removed_arena = "";
	public static String winner_an = "";
        
	public static String starting = "";// anouncements
	public static String started = "";// anouncements

        
public static void Load () {
    
    
    folder = Main.GetInstance().getDataFolder();
    config = Main.GetInstance().getConfig();

    //static File customYml = new File( Files.plugin.getDataFolder() + "/arenas.yml" );
    //static FileConfiguration customConfig = YamlConfiguration.loadConfiguration(Files.customYml);

    
    
		config.options().header("I recommend you to set auto_updating to true for possible future bugfixes. If use_economy is set to false, the winner will get the item reward.");
		config.addDefault("config.rounds_per_game", 10);
		config.addDefault("config.use_economy_reward", true);
		config.addDefault("config.money_reward_per_game", 30);
		config.addDefault("config.use_command_reward", false);
		config.addDefault("config.command_reward", "pex user <player> group set ColorPro");
		config.addDefault("config.start_announcement", false);
		config.addDefault("config.winner_announcement", false);

		config.addDefault("config.kits.default.name", "default");
		config.addDefault("config.kits.default.potioneffect", "SPEED");
		config.addDefault("config.kits.default.amplifier", 1);
		config.addDefault("config.kits.default.gui_item_id", 341);
		config.addDefault("config.kits.default.lore", "§2The default class.");

		config.addDefault("strings.saved.arena", "§aSuccessfully saved arena.");
		config.addDefault("strings.saved.lobby", "§aSuccessfully saved lobby.");
		config.addDefault("strings.saved.setup", "§6Successfully saved spawn. Now setting up, might §2lag§6 a little bit.");
		config.addDefault("strings.removed_arena", "§cSuccessfully removed arena.");
		config.addDefault("strings.not_in_arena", "§cYou don't seem to be in an arena right now.");
		config.addDefault("strings.config_reloaded", "§6Successfully reloaded config.");
		config.addDefault("strings.arena_is_ingame", "§cThe arena appears to be ingame.");
		config.addDefault("strings.arena_invalid", "§cThe arena appears to be invalid.");
		config.addDefault("strings.arena_invalid_sign", "§cThe arena appears to be invalid, because a join sign is missing.");
		config.addDefault("strings.arena_invalid_component", "§2The arena appears to be invalid (missing components or misstyped arena)!");
		config.addDefault("strings.you_fell", "§3You fell! Type §6/cm leave §3to leave.");
		config.addDefault("strings.you_won", "§aYou won this round, awesome man! Here, enjoy your reward.");
		config.addDefault("strings.starting_in", "§aStarting in §6");
		config.addDefault("strings.starting_in2", "§a seconds.");
		config.addDefault("strings.arena_full", "§cThis arena is full!");
		config.addDefault("strings.starting_announcement", "§aStarting a new ColorMatch Game in §6");
		config.addDefault("strings.started_announcement", "§aA new ColorMatch Round has started!");
		config.addDefault("strings.winner_announcement", "§6<player> §awon the game on arena §6<arena>!");

		config.options().copyDefaults(true);
                
		Main.GetInstance().saveConfig();
    
                
                
                LoadConfigVars();
                        
                        
}    
    
    
    
 	public static void LoadConfigVars() {
            
		rounds_per_game = config.getInt("config.rounds_per_game");
		default_max_players = config.getInt("config.default_max_players");
		default_min_players = config.getInt("config.default_min_players");
		reward = config.getInt("config.money_reward");
		itemid = config.getInt("config.itemid");
		itemamount = config.getInt("config.itemamount");
		command_reward = config.getBoolean("config.use_command_reward");
		cmd = config.getString("config.command_reward");
		start_countdown = config.getInt("config.start_countdown");
		start_announcement = config.getBoolean("config.start_announcement");
		winner_announcement = config.getBoolean("config.winner_announcement");
		bling_sounds = config.getBoolean("config.bling_sounds");

		saved_arena = config.getString("strings.saved.arena").replaceAll("§", "§");
		saved_lobby = config.getString("strings.saved.lobby").replaceAll("§", "§");
		saved_setup = config.getString("strings.saved.setup").replaceAll("§", "§");
		saved_mainlobby = "Successfully saved main lobby";
		not_in_arena = config.getString("strings.not_in_arena").replaceAll("§", "§");
		reloaded = config.getString("strings.config_reloaded").replaceAll("§", "§");
		arena_ingame = config.getString("strings.arena_is_ingame").replaceAll("§", "§");
		arena_invalid = config.getString("strings.arena_invalid").replaceAll("§", "§");
		arena_invalid_sign = config.getString("strings.arena_invalid_sign").replaceAll("§", "§");
		you_fell = config.getString("strings.you_fell").replaceAll("§", "§");
		arena_invalid_component = config.getString("strings.arena_invalid_component").replace("§", "§");
		you_won = config.getString("strings.you_won").replaceAll("§", "§");
		starting_in = config.getString("strings.starting_in").replaceAll("§", "§");
		starting_in2 = config.getString("strings.starting_in2").replaceAll("§", "§");
		arena_full = config.getString("strings.arena_full").replaceAll("§", "§");
		starting = config.getString("strings.starting_announcement").replaceAll("§", "§");
		started = config.getString("strings.started_announcement").replaceAll("§", "§");
		removed_arena = config.getString("strings.removed_arena").replaceAll("§", "§");
		winner_an = config.getString("strings.winner_announcement").replaceAll("§", "§");
	}
   
    
    
    
    
    
    
    
    
    /*
     public static void saveCustomYml(FileConfiguration fileconfiguration, File file) {
        try {
            fileconfiguration.save(file);
        } catch (IOException ex) {Main.log("§4Не удалось сохранить файл!!");}

    }
   */
    
    
    
    
    
}
