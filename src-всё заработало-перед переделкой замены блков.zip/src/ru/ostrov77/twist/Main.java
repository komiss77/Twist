package ru.ostrov77.twist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import mybs.API;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import ru.ostrov77.twist.Manager.Commands;
import ru.ostrov77.twist.Manager.Arenas;
import ru.ostrov77.twist.Manager.Files;
import ru.ostrov77.twist.Manager.Messages;
import ru.ostrov77.twist.Manager.ScoreBoard;
import ru.ostrov77.twist.Manager.Signs;




public class Main extends JavaPlugin implements Listener {

    public static Main instance;
    public static String Prefix;
    
    public static boolean mybsign = false;
    public static boolean noteblock = false;
    public static boolean bossbar = false;
    public static boolean ostrov = false;
    

        
    public static ArrayList<Byte> allowedColors = new ArrayList<>(Arrays.asList( (byte)0, (byte)1, (byte)3, (byte)5, (byte)7, (byte)9, (byte)11, (byte)13, (byte)15 ));
    public static HashMap <String, Long> cooldown = new HashMap();
    //public static ArrayList<DyeColor> colors = new ArrayList<>(Arrays.asList(DyeColor.BLUE, DyeColor.RED, DyeColor.CYAN, DyeColor.BLACK, DyeColor.GREEN, DyeColor.YELLOW, DyeColor.ORANGE, DyeColor.PURPLE));
    
    
        
        
        
        
        
        
        
        
        
@Override
       public void onLoad() {
        instance = this;
    }

       
@Override
	public void onEnable() {
                    
        Main.Prefix = ("§2[§a§bТвист§2] §f");
        
        if (Bukkit.getPluginManager().isPluginEnabled("NoteBlockAPI")) noteblock=true;
        if (Bukkit.getPluginManager().isPluginEnabled("MyBsign")) mybsign=true;
        if (Bukkit.getPluginManager().isPluginEnabled("BossBarAPI")) bossbar=true;
        if (Bukkit.getPluginManager().isPluginEnabled("Ostrov")) bossbar=true;
        
        if (!this.getDataFolder().exists())  this.getDataFolder().mkdir();
        else if (this.getConfig() == null)   this.saveDefaultConfig();
        else {
            MainConfig.Load();
            Files.loadAll();
            Signs.Load();
            Messages.Load();
        }


                
        Arenas.getManager();
        ScoreBoard.StartScore();
        if (mybsign) Arenas.MySign();
                

                
        Bukkit.getServer().getPluginManager().registerEvents(new GameListener(), this);
        Bukkit.getServer().getPluginManager().registerEvents(new Signs(), this);

        Bukkit.getLogger().info("Твист готов!");
        
	}

        
       
        
        
        
        
@Override
	public void onDisable() {
            
////////////////////////////////////////////////////////////////////////////////
                 
    if (mybsign) API.sendDataToServer("§4█████████<:>"
                        + "§2§l§oЗмейка<:>"
                        + "§c§lПерезапуск...<:>"
                        + "§4█████████<:>"
                        + "14");
                
////////////////////////////////////////////////////////////////////////////////
            
            this.saveConfig();
            Files.saveAll();
            Arenas.getManager().stopAllArena();
	}




        
        
@Override
    public boolean onCommand(CommandSender cs, Command comm, String s, String[] arg) {
            return Commands.handleCommand(cs, comm, s, arg);
    }


       
        
public static void log(String s) { Bukkit.getConsoleSender().sendMessage(Prefix + s);}        
        
public static final Main GetInstance() {
        return Main.instance;
    }  




        
        
        
        
       
        
        
        
        
public static boolean isNumber(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }    




public static boolean hasCooldown(String nik) {
    
	if(cooldown.containsKey(nik)) {
            
		if( System.currentTimeMillis() - cooldown.get(nik) >  3000 ) {
		    cooldown.remove (nik);
			return false;
		} else {return true;}
        } 
            return false;
}
		
	
public static void addCooldown(String nik) {
	if(!cooldown.containsKey(nik)) {
		cooldown.put(nik, System.currentTimeMillis());
	}
}
        
        
        
   
       


public static String[]  DyeToString ( byte num ) {
    
        String[] c =  {"",""};
        
     switch (num) {
        case 0: c[0]="§f"; c[1]="Белый"; break;    //+++бел
        case 1: c[0]="§6"; c[1]="Оранжевый"; break;
        case 2: c[0]="§d"; c[1]="Пурпурный"; break;
        case 3: c[0]="§9"; c[1]="Голубой"; break;
        case 4: c[0]="§e"; c[1]="Желтый"; break;
        case 5: c[0]="§a"; c[1]="Лаймовый"; break;
        case 6: c[0]="§c"; c[1]="Розовый"; break;
        case 7: c[0]="§8"; c[1]="т.-Серый"; break;
        case 8: c[0]="§7"; c[1]="Серый"; break;
        case 9: c[0]="§3"; c[1]="Аквамарин";
        case 10: c[0]="§d"; c[1]="т.-Фиолетовый";
        case 11: c[0]="§1"; c[1]="Синий"; break;
        case 12: c[0]="§6"; c[1]="Коричневый"; break;
        case 13: c[0]="§2"; c[1]="Зелёный"; break;
        case 14: c[0]="§4"; c[1]="Бардовый"; break;
        case 15: c[0]="§0"; c[1]="Чёрный"; break;
            default: c[0]="§f"; c[1]="Белый"; break;
    }
    return  c;
} 
    
    
public static Color  DyeToBukkitColor ( byte num ) {
    
     switch (num) {
        case 0: return Color.WHITE;     //+++бел
        case 1: return Color.ORANGE;
        case 2: return Color.PURPLE;
        case 3: return Color.BLUE;
        case 4: return Color.YELLOW;
        case 5: return Color.LIME;
        case 6: return Color.RED;
        case 7: return Color.SILVER;
        case 8: return Color.GRAY;
        case 9: return Color.TEAL;
        case 10: return Color.FUCHSIA;
        case 11: return Color.NAVY;
        case 12: return Color.OLIVE;
        case 13: return Color.GREEN;
        case 14: return Color.RED;
        case 15: return Color.BLACK;
            default: return Color.WHITE;
    }
} 
    



public static String getTime(final long n) {
    
        final long sec = TimeUnit.SECONDS.toSeconds(n) - TimeUnit.SECONDS.toMinutes(n) * 60L;
        final long min = TimeUnit.SECONDS.toMinutes(n) - TimeUnit.SECONDS.toHours(n) * 60L;

       // return  ( n2>0 ? n+":"+n2 : "00:"+n );
       return String.format("%02d", min) + ":" + String.format("%02d", sec);
    }




public static void GiveExitItem(Player p) {
        p.getInventory().clear();
        ItemStack leaveGame = new ItemStack(Material.SLIME_BALL, 1);
        ItemMeta im = leaveGame.getItemMeta();
        im.setDisplayName("Выход");
        leaveGame.setItemMeta(im);
        p.getInventory().setItem(8, leaveGame);
        p.updateInventory();
    }    
  


}
