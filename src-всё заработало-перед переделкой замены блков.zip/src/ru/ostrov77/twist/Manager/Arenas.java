package ru.ostrov77.twist.Manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import mybs.API;

import ru.ostrov77.twist.Main;
import ru.ostrov77.twist.Objects.Arena;






public class Arenas {

    private static Arenas am;
    private final HashMap <String, Arena> arenas = new HashMap();
    private static int curr=0;
    
    public Arenas(Main main) {}
    private Arenas() {}
    
    
    
public static Arenas getManager() {
        if (Arenas.am == null)   Arenas.am = new Arenas();
        return Arenas.am;
    }





public static void MySign() {
    
    
     (new BukkitRunnable() {
            @Override
            public void run() {

                if ( !getManager().getAllArenas().isEmpty() ){

                    final List<String> list = new ArrayList<>(am.arenas.keySet());
                        curr++;
                        if (curr >= list.size() ) curr = 0; 
        ////////////////////////////////////////////////////////////////////////////////
                
                    API.sendDataToServer("§b§l§oTWIST<:>"
                        + "§5§l"+am.arenas.get(list.get(curr)).getName()+"<:>"
                        + "§1"+am.arenas.get(list.get(curr)).getPlayers().size()+"<:>"
                        + "§5§l"+am.arenas.get(list.get(curr)).getStateAsString()+"<:>"
                        + "5");
                
////////////////////////////////////////////////////////////////////////////////
                }
                
            }
        }).runTaskTimer(Main.GetInstance(), 100L, 100L);      
}
 
    
    










public void createArena( String name, Location player_pos, String mode, byte size_x, byte size_z  ) {

                                // имя  коорд.угла  коорд.лобби   матер.  размер x * z4  сложность  раунды  мин.игроков  быстр.старт
        Arena arena = new Arena ( name, player_pos, player_pos,   mode,  size_x, size_z,  (byte)0, (byte)0,   (byte)0,    (byte)0 );
        this.arenas.put(name,arena);

    }


    
public void LoadArena(String name, Location zero, Location arenaLobby, String mode, byte size_x, byte size_z, byte diff, byte round, byte minpl, byte force ) {
 
                                // имя  коорд.угла  коорд.лобби   матер.  размер x * z4  сложность  раунды  мин.игроков  быстр.старт
        Arena arena = new Arena ( name,  zero,       arenaLobby,   mode,  size_x, size_z,  diff,    round,    minpl,       force );
        this.arenas.put(name,arena);
    }
    




public boolean CanCreate ( Player p) {
    boolean can=true;
    for (Entry <String, Arena> e : this.arenas.entrySet()) {
        if (e.getValue().getLobby().getWorld().getName().equals(p.getWorld().getName())) can=false;
    } 
    return can;
}


public HashMap<String,Arena> getAllArenas() { 
    return this.arenas;
    }
    

public Arena getArena(String s) {
         if (  !this.arenas.containsKey(s) ) return null;
         else return this.arenas.get(s);
    }
     
     
public boolean ArenaExist (String s) {
        return this.arenas.containsKey(s);
    }
    
 
public void startArenaByName(String s) {
        Arena arena = this.getArena(s);
        arena.ForceStart();
    }

public Arena getArenaByWorld(String w) {
    for (Entry <String, Arena> e : this.arenas.entrySet()) {
        if ( e.getValue().getLobby().getWorld().getName().equals(w)) return e.getValue();
    }
      return null;
    }
    
    
public void ResetArena(String s, Player p) {
        if (this.getArena(s) != null)  {
            this.getArena(s).resetGame();
            p.sendMessage("Arena "+s+" reset succes!");
        }
    }

public void DeleteArena(String s, Player p) {
        if (this.getArena(s) != null)  {
            this.getArena(s).stopShedulers();
            this.getArena(s).ResetFloor();
            Files.Delete(s);
            this.arenas.remove(s);
            p.sendMessage("Arena "+s+" delete succes!");
        }
    }


public void stopAllArena() {
    this.arenas.entrySet().stream().forEach((e) -> {
        e.getValue().resetGame();
    });
}
   
    
    
    
    
    
    
    
    
    
    
    
    
    
public void addPlayer(Player player, String s) {
    
        Arena arena = this.getArena(s);

        if (arena == null)  player.sendMessage("§сНет такой арены!");
        else if ( !arena.IsJonable() )   player.sendMessage("§4На арене идёт игра!");
        else if (arena.IsInGame(player))   player.sendMessage("§сВы уже в игре!");
        else if (arena.getName() == null)   player.sendMessage("§4Арена испортилась - нет названия..");
        else if (arena.getLobby() == null)  player.sendMessage("§4Арена испортилась - нет лобби ожидания..");
            
                    else  arena.addPlayers(player);
                    
    }

    
 
    
public boolean isInGame(Player p) {
    return this.arenas.entrySet().stream().anyMatch((e) -> (e.getValue().IsInGame(p)));
}


    
    
    
    
public void GlobalPlayerExit(Player p ) {
    this.arenas.entrySet().stream().forEach((e) -> {  e.getValue().PlayerExit(p); });
    }



public Arena getPlayersArena(Player p) {
    for (Entry <String, Arena> e : this.arenas.entrySet()) {
        if (e.getValue().IsInGame(p)) return e.getValue();
    }
    return null;
    }

    

    
    
      
    
    
    
    
 
    
    
    
    
    
    
    
    
 
    
    


 



    public void setArenaLobby(Location location, String s) {
        Arena arena = this.getArena(s);
        arena.setLobby(location);
    }
    


    
    
    
    
    
}
