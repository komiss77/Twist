package ru.ostrov77.twist.Manager;

import java.util.Map.Entry;
import org.bukkit.Bukkit;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import ru.ostrov77.twist.Main;

import ru.ostrov77.twist.Objects.Arena;

public class Commands extends JavaPlugin {

    public static boolean handleCommand(CommandSender sender, Command cmd, String s, String[] args) {
        
        if ( !(sender instanceof Player) ) return false;
        if ( !cmd.getName().equalsIgnoreCase("tw") && !cmd.getName().equalsIgnoreCase("twist")) return false;
        
        Player p= (Player) sender;
        
        if (args.length == 0) {
            Help(p);
            return false;
        }
        
        
    if (args[0].equalsIgnoreCase("join") ) {
            if (args.length == 2) {
                if (Arenas.getManager().getArena(args[1]) == null) {
                    p.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.joinInvalidArenaMessage));
                    return true;
                }

                Arenas.getManager().addPlayer((Player) p, args[1]);
            } else {
                p.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.joinArenaBadArguments));
            }

            return true;
            
        }    
            
            
            
            
            
     if ( !p.isOp()) return false; 

     
     
        
            
            
            
            
            
            
    if (args[0].equalsIgnoreCase("create")) {
               
                if ((args.length != 5 )) {
                    sender.sendMessage( "§cInsufficiant Arguments! Proper use of the command goes like this: ");
                    sender.sendMessage( "§b/tw create <name> <mode> <size_x> <size_z>");
                    sender.sendMessage( "§e<mode> may bee string §bwool, glass or clay");
                    sender.sendMessage( "§e<size_x> <size_z> may bee number from 2 to 64");
                    return false;
                    
                } else if ( !Main.isNumber(args[3]) || !Main.isNumber(args[4])  ) {
                            sender.sendMessage( "§c<size_x> <size_z> may bee number from 2 to 64");
                            return false;
                } else {
                
                    if (Arenas.getManager().ArenaExist(args[1])) 
                        sender.sendMessage("Арена с таким названием уже есть!");
                    else if (!Arenas.getManager().CanCreate((Player) sender))
                        sender.sendMessage("В этом мире уже есть арена!");
                    else if ( p.getWorld().getName().equals(Bukkit.getWorlds().get(0).getName()))
                        sender.sendMessage("В этом мире нельзя добавить арену! Это глобальное лобби");
                    else if ( p.getLocation().getY() < 10)
                        sender.sendMessage("Arena location(Y) mus bee highter, than 10!");
                    else if ( p.getLocation().getY() >250)
                        sender.sendMessage("Arena location(Y) mus bee lowest, than 250!");
                    else {
                                
                        Arenas.getManager().createArena( args[1], ((Player) sender).getLocation(), args[2], Byte.valueOf(args[3]), Byte.valueOf(args[4]) );
                        sender.sendMessage("Создана арена "+args[1]+" !");
                    }
                    
                }

                return true;
                
              
                
                
                
                
                
                
    } else  if ((args[0].equalsIgnoreCase("delete") )) {
                
                    if ((args.length != 2 )) {
                        sender.sendMessage( "§cInsufficiant Arguments! Proper use of the command goes like this: /tw delete <arena name>");
                    } else {
                        if (Arenas.getManager().getArena(args[1]) == null) {
                            sender.sendMessage( "§cThat arena doesn\'t exist!");
                            return true;
                            
                        } else {
                            sender.sendMessage( "§cTry to delete Arena...");
                            Arenas.getManager().DeleteArena (args[1], (Player) sender);
                        }
                    }
                    return true;
                    

                    
                
                
                
                
                
                
                    
    } else  if ((args[0].equalsIgnoreCase("list") )) {
                
                sender.sendMessage("§b§lАрен найдено: " + Arenas.getManager().getAllArenas().size() );
                
                for ( Entry<String, Arena> e : Arenas.getManager().getAllArenas().entrySet() ) {
                    sender.sendMessage( "§e" + e.getKey()+" :§5"+ e.getValue().getStateAsString()   );
                }
                
                return true;
                    
                
                
                
                
                
                
                    
    } else  if (args[0].equalsIgnoreCase("reset") ) {
                    
                    if ((args.length != 2 )) {
                        sender.sendMessage( "§cInsufficiant Arguments! Proper use of the command goes like this: /tw delete <arena name>");
                    } else {
                        if (Arenas.getManager().getArena(args[1]) == null) {
                            sender.sendMessage( "§cThat arena doesn\'t exist!");
                            return true;
                            
                        } else  {
                            sender.sendMessage( "§bTry to reset Arena...");
                            Arenas.getManager().ResetArena(args[1], (Player) sender);
                        }
                    }
                    return true;
                    
                    
                    
                                
                        
                        
                        
                        
                        
    } else if (args[0].equalsIgnoreCase("start")) {
                        
                        if ((args.length != 2  )) {
                            sender.sendMessage( "§cInsufficiant Arguments. Proper use of the command goes like this: /tw start <arena name>");
                        } else {
                            if (Arenas.getManager().getArena(args[1]) == null) {
                                sender.sendMessage( "§cThat arena doesn\'t exist!");
                                return true;
                            }
                            if (!Arenas.getManager().getArena(args[1]).IsJonable()) {
                                sender.sendMessage( "§cYou can\'t start an arena - arena in game!");
                                return true;
                            }
                            Arenas.getManager().startArenaByName(args[1]);
                            sender.sendMessage( "§bВремя до старта уменьшено");
                        }
                        return true;
                        
                        
                        
                        
                        
   }  else if (args[0].equalsIgnoreCase("setlobby") ) {
                            if ((args.length != 2 || !sender.hasPermission("supersnake.arenacreation")) && (args.length != 2 || !sender.isOp())) {
                                sender.sendMessage( "§cInsufficiant Arguments. Proper use of the command goes like this: /tw setlobby <arena name>");
                            } else {
                                if (Arenas.getManager().getArena(args[1]) == null) {
                                    sender.sendMessage( "§cThat arena doesn\'t exist!");
                                    return true;
                                }
                                if (Arenas.getManager().getArena(args[1]).getPlayers().size() > 0) {
                                    sender.sendMessage( "§cThat arena has players in it. Please stop the game before performing this operation.");
                                    return true;
                                }
                                Arenas.getManager().setArenaLobby(((Player) sender).getLocation(), args[1]);
                                sender.sendMessage( "§bSuccessfully set arena lobby!");
                            }
                            return true;
                            
                            
                            
                            
                            
    }  else if (args[0].equalsIgnoreCase("setminpl")) {
                            
            if (args.length == 3) {
                if (Arenas.getManager().getArena(args[1]) == null) {
                    sender.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.joinInvalidArenaMessage));
                    return true;
                }
                byte i;

                try { i = Byte.valueOf(args[2]); } 
                catch (Exception exception) {  sender.sendMessage( "§cThe third argument is not a valid int!"); return true; }

                Arenas.getManager().getArena(args[1]).setMinPlayers(i);
                sender.sendMessage( "§bSuccessfully set the min players to " + args[2] + "!");
            } else {
                sender.sendMessage( "§cProper usage of the command goes like this: /tw setminpl <arena name> <int>");
            }
            return true;
            
            
            
            
            
    }else if (args[0].equalsIgnoreCase("setround")) {
                            
            if (args.length == 3) {
                if (Arenas.getManager().getArena(args[1]) == null) {
                    sender.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.joinInvalidArenaMessage));
                    return true;
                }
                byte i;

                try { i = Byte.valueOf(args[2]); } 
                catch (Exception exception) {  sender.sendMessage( "§cThe third argument is not a valid int!"); return true; }

                Arenas.getManager().getArena(args[1]).setMaxRound(i);
                sender.sendMessage( "§bSuccessfully set the setround to " + args[2] + "!");
            } else {
                sender.sendMessage( "§cProper usage of the command goes like this: /tw setround <arena name> <int>");
            }
            return true;
            
            
            
            
            
            
    }else if (args[0].equalsIgnoreCase("setdiff")) {
                            
            if (args.length == 3) {
                if (Arenas.getManager().getArena(args[1]) == null) {
                    sender.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.joinInvalidArenaMessage));
                    return true;
                }
                byte i;

                try { i = Byte.valueOf(args[2]); } 
                catch (Exception exception) {  sender.sendMessage( "§cThe third argument is not a valid int from 1 to 3!"); return true; }

                Arenas.getManager().getArena(args[1]).setDifficulty(i);
                sender.sendMessage( "§bSuccessfully set the Difficulty to " + args[2] + "!");
            } else {
                sender.sendMessage( "§cProper usage of the command goes like this: /tw setdiff <arena name> <int>");
            }
            return true;
            
            
            
            
            
            
    } else if (args[0].equalsIgnoreCase("setforce")) {
                            
            if (args.length == 3) {
                if (Arenas.getManager().getArena(args[1]) == null) {
                    sender.sendMessage(ChatColor.translateAlternateColorCodes("&".charAt(0), Messages.joinInvalidArenaMessage));
                    return true;
                }
                byte i;

                try { i = Byte.valueOf(args[2]); } 
                catch (Exception exception) {  sender.sendMessage( "§cThe third argument is not a valid int!"); return true; }

                Arenas.getManager().getArena(args[1]).setForce(i);
                sender.sendMessage( "§bSuccessfully set the players to forcestart" + args[2] + "!");
            } else {
                sender.sendMessage( "§cProper usage of the command goes like this: /tw setforce <arena name> <int>");
            }
            return true;
            
            
            
            
            
            
    } else if (args[0].equalsIgnoreCase("saveall")) {

                sender.sendMessage( "§bTry to save data to disk...");
                Files.saveAll();
                sender.sendMessage( "§2Successfully save arenas to disk!");
                
            return true;
            
    }  else Help(p);
            
            
            
            
            
            
   
                        
                        
        
                
                return true;
            }
            
            

private static void Help (Player p ) {
    
                p.sendMessage("? аргументы ?");
            if ( p.isOp()) {
                p.sendMessage("create <арена>");
                p.sendMessage("delete <арена>");
                p.sendMessage("list");
                p.sendMessage("setlobby <арена>");
                p.sendMessage("setdiff <арена>");
                p.sendMessage("setround <арена>");
                p.sendMessage("setminpl <арена>");
                p.sendMessage("setforce <арена>");
                p.sendMessage("start <арена>");
                p.sendMessage("reset <арена>"); 
                p.sendMessage("saveall"); 
            }
            p.sendMessage("join <арена>");

}
    
    
            
    }
