package ru.ostrov77.twist.Manager;

import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.World;

import ru.ostrov77.twist.Main;
import ru.ostrov77.twist.Objects.Arena;



public class ScoreBoard {
 
     private static HashMap < UUID, Scoreboard > scoreStore = new HashMap<>();
     private static List <String> state = new ArrayList<>();
     
     
     
     
public static void StartScore () {     
         
  /*  
    (new BukkitRunnable() {
            @Override
            public void run() {
                
                
         for ( World w: Bukkit.getWorlds()) {
             
             for ( Player p : w.getPlayers() ) {

                updScoreData ( p, Arenas.getManager().getArenaByWorld(w.getName()) );
                p.setScoreboard(scoreStore.get (p.getUniqueId())); 
                
            }
         }
                
      
            }}).runTaskTimer(Main.GetInstance(), 3L, 20L);  
    
    
    
    
     (new BukkitRunnable() {
            @Override
            public void run() {
                
            state.clear();
            Arenas.getManager().getAllArenas().entrySet().stream().forEach((e) -> {
                state.add ( "§e" + e.getKey()+" : "+ e.getValue().getStateAsString()   );
            });
 
            }
        }).runTaskTimer(Main.GetInstance(), 19L, 100L);  
    */

     
}
 





  private static void updScoreData (Player p, Arena ar ) {   
   /*  
        
            final Scoreboard newScoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
            final Objective registerNewObjective = newScoreboard.registerNewObjective("vote", "dummy");
            registerNewObjective.setDisplaySlot(DisplaySlot.SIDEBAR);
            
            registerNewObjective.setDisplayName("§6§l§oЗмейка");
            
            registerNewObjective.getScore("§a-----------------").setScore(16); 
            
            
            
            
            
            
            
            if ( ar==null ) {        //если в лобби
                
                int pos=15;
                for (String ob:state) { 
                    registerNewObjective.getScore(ob).setScore(pos); 
                    pos--;
                }
                
                registerNewObjective.getScore("").setScore(pos); 
                pos--;
                registerNewObjective.getScore("§a------------------").setScore(pos); 
                
            
            
            
            
            } else {                                                    //если в мир игры
                
                
                
            registerNewObjective.getScore(ar.getScoreTimer()).setScore(15); 
            registerNewObjective.getScore("").setScore(14); 
            
            int pos=13;
            
            for (Player p2:ar.getPlayers()) {
                
                registerNewObjective.getScore(ar.GetScoreStatus(p2)).setScore(pos);
                pos--;
                
            }

            
            registerNewObjective.getScore("").setScore(pos); 
            pos--;
            registerNewObjective.getScore("§a------------------").setScore(pos); 
                
                
            }

           

           scoreStore.put(p.getUniqueId(), newScoreboard);
  */  
}
 
 
 

 
 
 

 
 
 
 
 
 
 
 
 
}
    














/*        
	public void updateScoreboard(String arena) {
		try {
			ScoreboardManager manager = Bukkit.getScoreboardManager();

			int count = 0;
			for (Player p_ : arenap.keySet()) {
				if (arenap.get(p_).equalsIgnoreCase(arena)) {
					count++;
				}
			}

			int lostcount = 0;
			for (Player p : arenap.keySet()) {
				if (arenap.get(p).equalsIgnoreCase(arena)) {
					if (lost.containsKey(p)) {
						lostcount++;
					}
				}
			}

			for (Player p : Bukkit.getOnlinePlayers()) {
				if (arenap.containsKey(p)) {
					if (arenap.get(p).equalsIgnoreCase(arena)) {
						Scoreboard board = manager.getNewScoreboard();

						Objective objective = board.registerNewObjective("test", "dummy");
						objective.setDisplaySlot(DisplaySlot.SIDEBAR);

						objective.setDisplayName("§cТ§3В§dИ§5С§6Т§e!"); // <- ColorMatch

						try {
							objective.getScore(Bukkit.getOfflinePlayer(" §8-  ")).setScore(5);
							objective.getScore(Bukkit.getOfflinePlayer("§aАрена:")).setScore(4);
							objective.getScore(Bukkit.getOfflinePlayer("§d" + arena)).setScore(3);
							objective.getScore(Bukkit.getOfflinePlayer(" §8- ")).setScore(2);
							objective.getScore(Bukkit.getOfflinePlayer("§aИграют:")).setScore(1);
							objective.getScore(Bukkit.getOfflinePlayer(Integer.toString(count - lostcount) + " из " + Integer.toString(count))).setScore(0);
						} catch (Exception e) {
							//
						}

						p.setScoreboard(board);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

        
        
	public void removeScoreboard(String arena) {
		try {
			ScoreboardManager manager = Bukkit.getScoreboardManager();
			Scoreboard sc = manager.getNewScoreboard();

			sc.clearSlot(DisplaySlot.SIDEBAR);

			getLogger().info("Removing scoreboard.");

			for (Player p : Bukkit.getOnlinePlayers()) {
				p.setScoreboard(sc);
				if (arenap.containsKey(p)) {
					if (arenap.get(p).equalsIgnoreCase(arena)) {
						getLogger().info(p.getName());
						p.setScoreboard(sc);
						p.setScoreboard(null);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void removeScoreboard(String arena, Player p) {
		try {
			ScoreboardManager manager = Bukkit.getScoreboardManager();
			Scoreboard sc = manager.getNewScoreboard();

			sc.clearSlot(DisplaySlot.SIDEBAR);
			p.setScoreboard(sc);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

        
   */     
        