package ru.ostrov77.twist.Manager;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import ru.ostrov77.twist.Main;






public class Messages {

    
    static File msgFile = new File(Main.GetInstance().getDataFolder() + "/messages.yml");
    static FileConfiguration msgConfig = YamlConfiguration.loadConfiguration(Messages.msgFile);
    
    public static String gameStartingIn;
    static String joinInvalidArenaMessage;
    static String joinArenaBadArguments;


    
    
    
    
    
    
  
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public static void Load() {
        Messages.msgConfig.addDefault("gameStartingIn", "&6&lGame Starting In [X] Seconds!");
        Messages.msgConfig.addDefault("joinInvalidArenaMessage", "&6&lGame Starting In [X] Seconds!");

        
        
        Messages.msgConfig.options().copyDefaults(true);
        
        saveCustomYml(Messages.msgConfig, Messages.msgFile);

        try {
            for (String s : Messages.msgConfig.getKeys(false)) {
                Field field = Messages.class.getField(s);
                field.setAccessible(true);
                field.set((Object) null, Messages.msgConfig.getString(s));
            }
        } catch (NoSuchFieldException | SecurityException | IllegalArgumentException | IllegalAccessException e) {
            Main.log("§4Не удалось загрузить перевод из файла!! Попробуйте удалить его! ");
        }

    }

    
    
    
    
    
    private static void saveCustomYml(FileConfiguration fileconfiguration, File file) {
        try {
            fileconfiguration.save(file);
        } catch (IOException e) {
            Main.log("§4Не удалось сохранить перевод в файл!!");
        }

    }
}
