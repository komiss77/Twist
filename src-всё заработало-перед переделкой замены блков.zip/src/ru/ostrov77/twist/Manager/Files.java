package ru.ostrov77.twist.Manager;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import org.bukkit.Bukkit;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

import ru.ostrov77.twist.Main;
import ru.ostrov77.twist.Objects.Arena;

public class Files {

    static Plugin plugin = Main.getPlugin(Main.class);
    static File customYml = new File( Files.plugin.getDataFolder() + "/arenas.yml" );
    static FileConfiguration customConfig = YamlConfiguration.loadConfiguration(Files.customYml);
    
    
    
    
    
    
    
    public static int priceColorChooser = 450;



    
    
    
    
    
    
    
    

    public static void loadAll() {
        try {
            loadBasic();
            Files.customConfig.options().copyDefaults(true);
            Files.plugin.getConfig().options().copyDefaults(true);
            Files.plugin.saveConfig();
            if (Files.customConfig.getConfigurationSection("Arenas") ==null)    return;
            
            ConfigurationSection cconf = Files.customConfig.getConfigurationSection("Arenas");
            
            for (String name : cconf.getKeys(false)) {

                 
                Arenas.getManager().LoadArena( 
                        name, 
                        stringToLoc ( cconf.getString ( name + ".zeropoint" ) ),
                        stringToLoc ( cconf.getString ( name + ".arenalobby" ) ),
                        cconf.getString(name + ".mode" ),
                        (byte) cconf.getInt( name + ".size_x" ),
                        (byte) cconf.getInt( name + ".size_z" ),
                        (byte) cconf.getInt( name + ".difficulty" ),
                        (byte) cconf.getInt( name + ".round" ),
                        (byte) cconf.getInt( name + ".minPlayers" ),
                        (byte) cconf.getInt( name + ".playersForForcestart" )
                );
            
            }
            
        } catch (NullPointerException e) {}

    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public static void loadBasic() {
        
        
        
        
        Files.plugin.getConfig().addDefault("priceColorChooser", 450);
        
        

        Files.plugin.getConfig().options().copyDefaults(true);
        Files.plugin.saveConfig();
        
        
        
        
        
        
        
        Files.priceColorChooser = Files.plugin.getConfig().getInt("priceColorChooser");


    }
    
    
  
    
    
    
    
    
    
    
    
    
    public static void saveAll() {


            Arena arena;

            
            for (Entry <String, Arena> e : Arenas.getManager().getAllArenas().entrySet()) {
                
                arena = e.getValue();
                

               // ConfigurationSection cs = Files.customConfig.getConfigurationSection("Arenas." + arena.getName());
                
                Files.customConfig.set( "Arenas." + arena.getName()+ ".zeropoint" , locToString(arena.getZero()) );
                Files.customConfig.set( "Arenas." + arena.getName()+ ".arenalobby" , locToString(arena.getLobby()) );
                Files.customConfig.set( "Arenas." + arena.getName()+ ".mode", arena.getMode());
                Files.customConfig.set( "Arenas." + arena.getName()+ ".size_x", arena.getSize_x());
                Files.customConfig.set( "Arenas." + arena.getName()+ ".size_z", arena.getSize_z());
                Files.customConfig.set( "Arenas." + arena.getName()+ ".difficulty", arena.getDifficulty());
                Files.customConfig.set( "Arenas." + arena.getName()+ ".round", arena.getMaxRound());
                Files.customConfig.set( "Arenas." + arena.getName()+ ".minPlayers", arena.getMinPlayers());
                Files.customConfig.set( "Arenas." + arena.getName()+ ".playersForForcestart", arena.getForce());
               
            }
 

            Files.plugin.saveConfig();
            saveCustomYml(Files.customConfig, Files.customYml);
    }
    
    
 
    
    public static void Delete( String name ) {

        if (Files.customConfig.getConfigurationSection("Arenas") == null)    return;
        
        Files.customConfig.set("Arenas." + name,  null);
        saveCustomYml(Files.customConfig, Files.customYml);
        
        
        
        saveCustomYml(Files.customConfig, Files.customYml);
        
    }
    
    
    
    
    
    
     public static Location stringToLoc(String s) {
        if (s != null && !s.trim().equals("")) {
            String[] astring = s.split("<>");

            if (astring.length == 4) {
                World world = Bukkit.getServer().getWorld(astring[0]);
                Double d = Double.parseDouble(astring[1]);
                Double double1 = Double.parseDouble(astring[2]);
                Double double2 = Double.parseDouble(astring[3]);

                return new Location(world, d, double1, double2);
            } else {
                return null;
            }
        } else {
            return null;
        }
    }
     
     
    public static String locToString(Location location) {
        return location == null ? "" : location.getWorld().getName() + "<>" + location.getBlockX() + "<>" + location.getBlockY() + "<>" + location.getBlockZ();
    }

   
    
     public static void saveCustomYml(FileConfiguration fileconfiguration, File file) {
        try {
            fileconfiguration.save(file);
        } catch (IOException ioexception) {
           // ioexception.printStackTrace();
        }

    }
   
    
    
    
    
    
}
