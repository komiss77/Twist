package ru.ostrov77.twist;


import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockFadeEvent;
import org.bukkit.event.block.BlockGrowEvent;
import org.bukkit.event.block.BlockSpreadEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.weather.ThunderChangeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.world.StructureGrowEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.event.Listener;

import io.puharesource.mc.titlemanager.api.TitleObject;
import org.bukkit.Effect;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.EntityType;
import org.bukkit.event.EventPriority;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerPickupItemEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import ru.komiss77.Ostrov;

import ru.ostrov77.twist.Manager.Arenas;






public class GameListener implements Listener {
 
    public GameListener() {}
    
    
@EventHandler
    public void onPlayerJoin(PlayerJoinEvent e) {
                e.setJoinMessage(null);
                
        e.setJoinMessage(null);
        
        JoinPlayer(e.getPlayer());
        e.getPlayer().teleport(Bukkit.getServer().getWorlds().get(0).getSpawnLocation());
        
        if (!e.getPlayer().hasPlayedBefore()) {
            (new TitleObject (("§2Игра §aТВИСТ !"), TitleObject.TitleType.TITLE)).setFadeIn(40).setStay(80).setFadeOut(40).send(e.getPlayer());
            (new TitleObject (("§fВыберите арену с помощью табличек!"), TitleObject.TitleType.SUBTITLE)).setFadeIn(40).setStay(80).setFadeOut(40).send(e.getPlayer());
        }


    }
    
 
        


    
    
    
    public void JoinPlayer (Player p) {
        if (!p.isOp()) p.setGameMode(GameMode.ADVENTURE);
        p.setFireTicks(0);
        p.getInventory().clear();
        p.setFlying(false);
        p.setAllowFlight(false);
        p.setFoodLevel(20);
        p.setHealth(20);
        p.setLevel(0);
        p.setExp(0);
        p.setWalkSpeed(0.2F);
        p.getInventory().setItem(0, Ostrov.pipboy);
        p.updateInventory();
    }

    
    
    
    
@EventHandler
    public void PlayerQuitEvent (PlayerQuitEvent playerquitevent) {
        Player player = playerquitevent.getPlayer();
        Arenas.getManager().GlobalPlayerExit(player);
    }
        

        
        
        
        
        
@EventHandler
    public void onInteraction(PlayerInteractEvent e) {
                   
        if ( e.getAction() == Action.RIGHT_CLICK_AIR || e.getAction() == Action.RIGHT_CLICK_BLOCK ){
            
            if (Arenas.getManager().isInGame(e.getPlayer())) {
                e.setCancelled(true);
                e.getPlayer().sendMessage("Во время игры недоступно!");
                return;
            }
                  
            switch (e.getMaterial()) {
                
                case SLIME_BALL:
                    e.setCancelled(true);
                    Arenas.getManager().GlobalPlayerExit (e.getPlayer());
                    break;
                    
                default:
                    break;
                
            }      
        

        }
    }
               


    
    
     
    
    
@EventHandler
        public void onEntityDamage(EntityDamageEvent e) { 
        
            if ( !(e.getEntity() instanceof Player) ) { e.setCancelled(true); return; }
            
            Player p = (Player) e.getEntity();
            
            
            switch (e.getCause()) {
                
                case VOID:
                    e.setCancelled(true);
                    if ( Arenas.getManager().isInGame(p) )  Arenas.getManager().GlobalPlayerExit(p);      //если где-то играет
                    else { JoinPlayer (p); p.teleport(Bukkit.getServer().getWorlds().get(0).getSpawnLocation()); }
                    
                    break;
                    
                    
                case FALL:
                    e.setCancelled(true);
                    if  ( Arenas.getManager().isInGame(p) ) {
                        Arenas.getManager().getPlayersArena(p).Loose(p);
                    } else e.setCancelled(true);
                    break;
                    
                case ENTITY_ATTACK:
                    if (e.getEntityType() == EntityType.PIG_ZOMBIE) e.setCancelled(true);
                    break;
                    
                default:
                    e.setCancelled(true);
                    break;
                    
                
                    
                
            }
            
            
        
    }      
  

        
    
@EventHandler
    public void sugarPickupEventSpeed(PlayerPickupItemEvent e) {
            Player p = e.getPlayer();

            
            switch (e.getItem().getItemStack().getType()) {
                
                case FEATHER:
System.out.println("подобрал перо");                    
                    e.setCancelled(true);
                    e.getItem().remove();
                    if  ( Arenas.getManager().isInGame(p) ) {
                        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 9.9F);
                        p.getWorld().playEffect(p.getLocation(), Effect.LAVA_POP, 0);
                    }
                    break;
                    
                default:
                    e.setCancelled(true);
                    e.getItem().remove();
                    p.playSound(p.getLocation(), Sound.ENTITY_CHICKEN_EGG, 1.0F, 9.9F);
                    break;
                    
                
            }


    }
        
        

    
    
    
    
@EventHandler
    public void onHostileSpawn(CreatureSpawnEvent e) {
        
        if ( e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.CUSTOM ) {
            e.setCancelled(true);
        }

    }
   

    
    
    
@EventHandler(  priority = EventPriority.NORMAL)
    public void onInventoryClick(InventoryClickEvent e) {

        if (e.getCurrentItem() != null && e.getCurrentItem().getType() != null) {
            
            if (Arenas.getManager().isInGame((Player) e.getWhoClicked())) {
                e.setCancelled(true);
            } else if ( e.getCurrentItem().getType()==Material.SLIME_BALL) {
                e.setCancelled(true);
            }
            
        }
    }

        
@EventHandler
    public void onDrop(PlayerDropItemEvent event) {
        if (event.getPlayer().isOp()) return;
                            event.setCancelled(true);
                            event.getItemDrop().remove();
                            ItemStack droped = event.getPlayer().getItemInHand().clone();
                            droped.setAmount(1);
                            event.getPlayer().setItemInHand(droped);
                            event.getPlayer().updateInventory();
    }     
    
                
   
/*    
@EventHandler
    public void cancelMove(InventoryDragEvent event) {
       event.setCancelled(true);
        ((Player) event.getWhoClicked()).updateInventory();
    }
 */   
    
     
        
@EventHandler
        public void onPlayerDeath(PlayerDeathEvent e) {
            e.setDeathMessage(null);
            e.setDroppedExp(0);
            Player p = e.getEntity();
            
            World w = p.getWorld();
            
            new BukkitRunnable() {
                @Override
                    public void run() {
                        
			p.spigot().respawn();
                        p.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, 80, 1), true);
                                JoinPlayer(p);
                                                    //если на арене игрока еще игра, в лобби игры, если нет-в глобальное лобби
                            if ( !Arenas.getManager().getArenaByWorld( w.getName()).IsJonable() )  {
                                p.teleport( Arenas.getManager().getArenaByWorld( w.getName()).getLobby());
                                Arenas.getManager().getArenaByWorld( w.getName()).RemovePZ(p.getName());
                            }
                            else p.teleport(Bukkit.getServer().getWorlds().get(0).getSpawnLocation());
                                
                    }
		}.runTaskLater(Main.GetInstance(), 20L);
            
        }   
   
    

        
        
        
        
    
    
    
        
@EventHandler
    public void WorldChange (PlayerChangedWorldEvent e) {
        if (e.getPlayer().getWorld().getName().equals(Bukkit.getWorlds().get(0).getName())) {
            JoinPlayer (e.getPlayer());
            e.getPlayer().teleport(Bukkit.getServer().getWorlds().get(0).getSpawnLocation());
        }
    }



    
        
        
        
    
    
@EventHandler
    public void onPlayerSwapoffHand(PlayerSwapHandItemsEvent event) {
        if (event.getOffHandItem() != null  )  event.setCancelled(true);
    }    
  

    
    
    
    
   
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
@EventHandler
    public void blockGrow(BlockGrowEvent event) {
         event.setCancelled(true);
    }    
    
    
@EventHandler
    public void strucGrow(StructureGrowEvent event) {
          event.setCancelled(true);
    }    
    
@EventHandler
    public void onBlockSpread(BlockSpreadEvent event) {
          event.setCancelled(true);
    }    

    
@EventHandler
    public void onWeatherChange(WeatherChangeEvent event) {
        boolean rain = event.toWeatherState();
        if(rain)
            event.setCancelled(true);
    }
 
@EventHandler
    public void onThunderChange(ThunderChangeEvent event) {
        boolean storm = event.toThunderState();
        if(storm)
            event.setCancelled(true);
    } 

    
@EventHandler
    public void onBlockFade(BlockFadeEvent event)
    {
        if(event.getBlock().getType() == Material.ICE || event.getBlock().getType() == Material.PACKED_ICE || event.getBlock().getType() == Material.SNOW || event.getBlock().getType() == Material.SNOW_BLOCK) 
            event.setCancelled(true);
    }
  

        
@EventHandler
	public void onHunger(FoodLevelChangeEvent event) { event.setCancelled(true); }

        
        
@EventHandler
    public void PlayerArmorStandManipulateEvent(PlayerArmorStandManipulateEvent e){
        if (!e.getPlayer().isOp()) e.setCancelled(true);
    }    
     
  


}
